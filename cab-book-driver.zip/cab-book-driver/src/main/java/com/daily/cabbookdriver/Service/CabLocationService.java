//package com.daily.cabbookdriver.Service;
//
//import com.daily.cabbookdriver.constant.AppConstant;
//import org.springframework.kafka.core.KafkaTemplate;
//import org.springframework.stereotype.Service;
//
//@Service
//public class CabLocationService {
//
//    private static KafkaTemplate<String,Object> kafkaTemplate;
//    public static boolean updateLocation(String location){
//        kafkaTemplate.send(AppConstant.CAB_LOCATION,location);
//        return true;
//    }
//}
package com.daily.cabbookdriver.Service;

import com.daily.cabbookdriver.constant.AppConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class CabLocationService {

    private final KafkaTemplate<String, Object> kafkaTemplate;

    @Autowired
    public CabLocationService(KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public boolean updateLocation(String location) {
        kafkaTemplate.send(AppConstant.CAB_LOCATION, location);
        return true;
    }
}
