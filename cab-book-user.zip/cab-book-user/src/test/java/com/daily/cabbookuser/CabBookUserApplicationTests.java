package com.daily.cabbookuser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CabBookUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
